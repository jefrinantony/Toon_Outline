# Outline Tool v2.6

## Installation Instructions:

1. Download and extract the Zip file.

2. Paste the folder "OutlineV2.6" into your Maya scripts directory: 

	The directory structure should look like this:	C:/Users/{username}/Documents/maya/scripts/OutlineV2.6


3. Open Maya and drag-drop the file "OutlineV2.6.py" from the script folder into the Maya script editor.

4. Run the script. You can save it in the shelf for future use.

## Notes:

- This script is compatible with Maya version 2022 and above. It may not work with older versions.
- If you encounter any issues or need assistance, refer to the troubleshooting section below or seek help from the Maya community forums.

## Troubleshooting:

- **Issue:** Script not running in Maya.
**Solution:** Ensure that the script is saved in the correct directory and that your Maya version is compatible with Python 3.

- For more help and support, visit the Maya community forums or contact the script author at antony.jefrin19@.com.