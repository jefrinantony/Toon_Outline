import maya.cmds as cmds
import os
import getpass

# Version 2.6: Outline Tool with Enhanced UI, Adjustable Thickness, and Dynamic Control

# Global variables
outline_group_name = "outline_group"
use_background_material_name = "useBackground_material"
color_shaders = {}
translateZ_slider = None
outline_meshes = {}

def set_double_sided(mesh_name):
    attr_name = mesh_name + ".doubleSided"
    try:
        cmds.setAttr(attr_name, 0)
    except Exception as e:
        cmds.warning("Error setting doubleSided attribute for {}: {}".format(mesh_name, str(e)))

def create_outline_mesh(original_mesh, outline_color, translate_z):
    outline_mesh = cmds.duplicate(original_mesh, name=original_mesh + "_outline")[0]
    set_double_sided(outline_mesh)
    
    # Connect output mesh of original mesh to input mesh of outline mesh
    original_shape = cmds.listRelatives(original_mesh, shapes=True)[0]
    outline_shape = cmds.listRelatives(outline_mesh, shapes=True)[0]
    cmds.connectAttr(original_shape + ".outMesh", outline_shape + ".inMesh", force=True)
    
    move_facet_operation = adjust_outline_mesh(outline_mesh, outline_color, translate_z)
    
    return outline_mesh, move_facet_operation

def adjust_outline_mesh(outline_mesh, outline_color, translate_z):
    # Set outline color
    outline_shader = create_color_surface_shader(outline_color)
    apply_color_to_group(outline_mesh, outline_shader)

    # Move facets along the local Z-axis with the specified value
    move_facet_operation = cmds.polyMoveFacet(outline_mesh + ".f[*]", localTranslateZ=translate_z)

    # Calculate normals
    cmds.polyNormal(outline_mesh, normalMode=0)

    return move_facet_operation

def update_outline_thickness(translate_z):
    for outline_mesh, move_facet_operation in outline_meshes.items():
        if cmds.objExists(outline_mesh):
            cmds.polyMoveFacet(move_facet_operation, edit=True, localTranslateZ=translate_z)
    
    # Save the current slider value to optionVar
    cmds.optionVar(floatValue=["outline_thickness_slider_value", translate_z])

def create_use_background_material():
    if not cmds.objExists(use_background_material_name):
        shading_node = cmds.shadingNode('useBackground', asShader=True, name=use_background_material_name)
        shading_group = cmds.sets(renderable=True, noSurfaceShader=True, empty=True)
        cmds.connectAttr(shading_node + '.outColor', shading_group + '.surfaceShader', force=True)

def apply_use_background_material(mesh_name):
    create_use_background_material()
    try:
        cmds.select(mesh_name)
        cmds.hyperShade(assign=use_background_material_name)
    except Exception as e:
        cmds.warning("Error applying 'Use Background Material': {}".format(str(e)))

def apply_color_to_group(group_name, shader_name):
    shading_group = cmds.sets(renderable=True, noSurfaceShader=True, empty=True)
    cmds.connectAttr(shader_name + '.outColor', shading_group + '.surfaceShader', force=True)
    cmds.select(group_name)
    cmds.hyperShade(assign=shader_name)

def create_color_surface_shader(color):
    shader_name = "color_surface_shader_{}".format('_'.join(map(str, color)))
    if shader_name in color_shaders:
        return color_shaders[shader_name]
    
    if cmds.objExists(shader_name):
        shader = shader_name
    else:
        shader = cmds.shadingNode('surfaceShader', asShader=True, name=shader_name)
        cmds.setAttr(shader + ".outColor", color[0], color[1], color[2], type="double3")
        shading_group = cmds.sets(renderable=True, noSurfaceShader=True, empty=True)
        cmds.connectAttr(shader + ".outColor", shading_group + ".surfaceShader", force=True)
        color_shaders[shader_name] = shader
    
    return shader

def create_outline(selected_meshes):
    translate_z = cmds.floatSliderGrp(translateZ_slider, query=True, value=True) * 0.01
    if not cmds.objExists(outline_group_name):
        cmds.group(name=outline_group_name, empty=True)

    outline_color = [1, 0, 0]  # Adjust the outline color here (R, G, B)

    global outline_meshes
    for original_mesh in selected_meshes:
        outline_mesh, move_facet_operation = create_outline_mesh(original_mesh, outline_color, translate_z)
        outline_meshes[outline_mesh] = move_facet_operation
        cmds.parent(outline_mesh, outline_group_name)
        try:
            point_constraint = cmds.pointConstraint(original_mesh, outline_mesh)[0]
            orient_constraint = cmds.orientConstraint(original_mesh, outline_mesh)[0]
            apply_use_background_material(original_mesh)
            cmds.setAttr(outline_mesh + ".overrideEnabled", 1)
            cmds.setAttr(outline_mesh + ".overrideDisplayType", 2)
        except:
            apply_use_background_material(original_mesh)
    
    # Save outline meshes to optionVar
    cmds.optionVar(clearArray="outline_meshes")
    for outline_mesh, move_facet_operation in outline_meshes.items():
        cmds.optionVar(stringValueAppend=("outline_meshes", outline_mesh))
        cmds.optionVar(stringValueAppend=("outline_meshes", move_facet_operation[0]))

def delete_outlines():
    global outline_meshes
    if cmds.objExists(outline_group_name):
        try:
            # Apply Lambert material to the original meshes
            for outline_mesh, move_facet_operation in outline_meshes.items():
                original_mesh = outline_mesh.replace("_outline", "")
                if cmds.objExists(original_mesh):
                    lambert_shader = create_lambert_shader()
                    apply_color_to_group(original_mesh, lambert_shader)
            
            cmds.delete(outline_group_name)
            if cmds.objExists(use_background_material_name):
                cmds.delete(use_background_material_name)
        except Exception as e:
            cmds.warning("Error deleting outlines: {}".format(str(e)))

    for shader in color_shaders.values():
        if cmds.objExists(shader):
            try:
                cmds.delete(shader)
            except Exception as e:
                cmds.warning("Error deleting shader: {}".format(str(e)))

    # Clear the outline_meshes dictionary
    outline_meshes.clear()

    # Clear the saved outline meshes from optionVar
    cmds.optionVar(clearArray="outline_meshes")

def create_lambert_shader():
    lambert_name = "lambert_shader"
    if not cmds.objExists(lambert_name):
        lambert_shader = cmds.shadingNode('lambert', asShader=True, name=lambert_name)
    return lambert_name

def load_outline_meshes():
    global outline_meshes
    outline_meshes = {}
    outline_meshes_list = cmds.optionVar(query="outline_meshes")
    if outline_meshes_list:
        for i in range(0, len(outline_meshes_list), 2):
            outline_mesh = outline_meshes_list[i]
            move_facet_operation = outline_meshes_list[i + 1]
            outline_meshes[outline_mesh] = [move_facet_operation]

def create_outline_window():
    global translateZ_slider
    if cmds.window("outlineWindow", exists=True):
        cmds.deleteUI("outlineWindow", window=True)

    # Load outline meshes
    load_outline_meshes()

    # Get the username of the current user
    username = getpass.getuser()

    # Define the path relative to the user's documents directory
    relative_path = f"C:/Users/{username}/Documents/maya/scripts/OutlineV2.6/Icons"

    # Expand the path to the absolute directory
    icon_directory = os.path.expanduser(relative_path)

    window = cmds.window("outlineWindow", title="Outline Tool 2.7", widthHeight=(300, 250), sizeable=False)
    main_layout = cmds.columnLayout(adjustableColumn=True, parent=window)

    # UI components
    cmds.text(label="Outline Tool", align="center", font="boldLabelFont", parent=main_layout)
    cmds.separator(height=10, style="none", parent=main_layout)

    create_button = cmds.button(label="Create Outline", bgc=[0.4, 0.6, 0.8], command=lambda *args: create_outline(cmds.ls(selection=True)), parent=main_layout)
    delete_button = cmds.button(label="Delete Outlines", bgc=[0.8, 0.4, 0.4], command="delete_outlines()", parent=main_layout)

    cmds.separator(height=15, style="none", parent=main_layout)

    cmds.text(label="Outline Color", align="center", font="boldLabelFont", parent=main_layout)
    color_layout = cmds.gridLayout(numberOfColumns=4, cellWidthHeight=(75, 75), parent=main_layout)

    # Function to create circular buttons with specified color
    def create_color_button(color, parent, image_path):
        button = cmds.symbolButton(image=image_path, command=lambda *args: apply_color_to_group(outline_group_name, create_color_surface_shader(color)), parent=parent, width=75, height=75)
        return button

    # Now, use the dynamically constructed icon_directory
    red_image = os.path.join(icon_directory, "Red.png")
    blue_image = os.path.join(icon_directory, "Blue.png")
    green_image = os.path.join(icon_directory, "Green.png")
    cyan_image = os.path.join(icon_directory, "Cyan.png")

    red_button = create_color_button([0.9, 0.2, 0.2], color_layout, red_image)
    blue_button = create_color_button([0.2, 0.4, 0.9], color_layout, blue_image)
    green_button = create_color_button([0.2, 0.7, 0.2], color_layout, green_image)
    cyan_button = create_color_button([0.2, 0.7, 0.7], color_layout, cyan_image)

    cmds.separator(height=15, style="none", parent=main_layout)

    cmds.text(label="Outline Thickness", align="center", font="boldLabelFont", parent=main_layout)
    cmds.separator(height=5, style="none", parent=main_layout)

    # Load saved slider value
    saved_slider_value = cmds.optionVar(query="outline_thickness_slider_value") if cmds.optionVar(exists="outline_thickness_slider_value") else 50

    translateZ_slider = cmds.floatSliderGrp(label="Thickness", field=True, minValue=1, maxValue=500, fieldMinValue=1, fieldMaxValue=100, value=saved_slider_value, columnWidth3=[90, 40, 150], parent=main_layout, dc=lambda *args: update_outline_thickness(cmds.floatSliderGrp(translateZ_slider, query=True, value=True) * 0.01))

    # Show the window
    cmds.showWindow(window)

    # Apply the saved thickness value to existing outlines
    update_outline_thickness(saved_slider_value * 0.01)

# Create the outline window
create_outline_window()
